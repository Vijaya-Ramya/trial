from tkinter import *

from db import Database

db = Database('store.db')


def populate_list():
    car_list.delete(0, END)
    for row in db.fetch():
        car_list.insert(END, row)

def add_item():
    db.insert(car_name.get(), car_type.get(), car_color.get(), car_price.get(), car_status.get())
    car_list.delete(0, END)
    car_list.insert(END, (car_name.get(), car_type.get(), car_color.get(), car_price.get(), car_status.get()))
    clear_item()
    populate_list()

def select_item(event):
    try:
        global selected_item
        index = car_list.curselection()[0]
        selected_item = car_list.get(index)

        car_name_entry.delete(0, END)
        car_name_entry.insert(END, selected_item[1])
        car_type_entry.delete(0, END)
        car_type_entry.insert(END, selected_item[2])
        car_color_entry.delete(0, END)
        car_color_entry.insert(END, selected_item[3])
        car_price_entry.delete(0, END)
        car_price_entry.insert(END, selected_item[4])
        car_status_entry.delete(0, END)
        car_status_entry.insert(END, selected_item[5])

    except IndexError:
        pass

def remove_item():
    db.remove(selected_item[0])
    clear_item()
    populate_list()

def update_item():
    db.update(selected_item[0], car_name.get(), car_type.get(), car_color.get(), car_price.get(), car_status.get())
    populate_list()

def clear_item():
    car_name_entry.delete(0, END)
    car_type_entry.delete(0, END)
    car_color_entry.delete(0, END)
    car_price_entry.delete(0, END)
    car_status_entry.delete(0, END)

app = Tk()

# car rental management system
app.title("Car Management System")
app.geometry("1350x750+0+0")

# background image
bg = PhotoImage(file="car.png")
bg_image = Label(app, image=bg).place(x=0, y=0, relwidth=1, relheight=1)

# title
title = Label(app, text="Car Rental Management System", bd=10, relief=GROOVE, font=("times new roman", 40, "bold"), bg="yellow", fg="red")
title.pack(side=TOP, fill=X)

# car rental management system

# add car
car_name = StringVar()
car_name_label = Label(app, text="Car Name", font=("times new roman", 20, "bold"), bg="yellow", fg="red")
car_name_label.place(x=100, y=100)
car_name_entry = Entry(app, textvariable=car_name, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
car_name_entry.place(x=350, y=100, width=250)

# car type
car_type = StringVar()
car_type_label = Label(app, text="Car Type", font=("times new roman", 20, "bold"), bg="yellow", fg="red")
car_type_label.place(x=100, y=150)
car_type_entry = Entry(app, textvariable=car_type, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
car_type_entry.place(x=350, y=150, width=250)

# car color
car_color = StringVar()
car_color_label = Label(app, text="Car Color", font=("times new roman", 20, "bold"), bg="yellow", fg="red")
car_color_label.place(x=100, y=200)
car_color_entry = Entry(app, textvariable=car_color, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
car_color_entry.place(x=350, y=200, width=250)

# car price
car_price = StringVar()
car_price_label = Label(app, text="Car Price", font=("times new roman", 20, "bold"), bg="yellow", fg="red")
car_price_label.place(x=100, y=250)
car_price_entry = Entry(app, textvariable=car_price, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
car_price_entry.place(x=350, y=250, width=250)

# car status
car_status = StringVar()
car_status_label = Label(app, text="Car Status", font=("times new roman", 20, "bold"), bg="yellow", fg="red")
car_status_label.place(x=100, y=300)
car_status_entry = Entry(app, textvariable=car_status, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
car_status_entry.place(x=350, y=300, width=250)


# list of cars
car_list = Listbox(app, font=("times new roman", 15, "bold"), bd=5, relief=GROOVE)
car_list.place(x=700, y=100, width=600, height=400)

# scroll bar
scroll_bar = Scrollbar(car_list)
scroll_bar.pack(side=RIGHT, fill=Y)
scroll_bar.config(command=car_list.yview)
car_list.config(yscrollcommand=scroll_bar.set)

# buttons
add_btn = Button(app, text="Add Car", font=("times new roman", 15, "bold"), bg="yellow", fg="red", bd=5, relief=GROOVE, width=10)
add_btn.place(x=100, y=400)

update_btn = Button(app, text="Update Car", font=("times new roman", 15, "bold"), bg="yellow", fg="red", bd=5, relief=GROOVE, width=10)
update_btn.place(x=250, y=400)

delete_btn = Button(app, text="Delete Car", font=("times new roman", 15, "bold"), bg="yellow", fg="red", bd=5, relief=GROOVE, width=10)
delete_btn.place(x=400, y=400)

clear_btn = Button(app, text="Clear", font=("times new roman", 15, "bold"), bg="yellow", fg="red", bd=5, relief=GROOVE, width=10)
clear_btn.place(x=550, y=400)


add_btn.config(command=add_item)
car_list.bind('<<ListboxSelect>>', select_item)
update_btn.config(command=update_item)
delete_btn.config(command=remove_item)
clear_btn.config(command=clear_item)

# close button
close_btn = Button(app, text="Close", font=("times new roman", 15, "bold"), bg="yellow", fg="red", bd=5, relief=GROOVE, width=10)
close_btn.place(x=700, y=400)
close_btn.config(command=app.destroy)

populate_list()

app.mainloop()

# code to make it executable using pyinstaller
# pyinstaller --onefile --windowed --icon=car.ico main.py

