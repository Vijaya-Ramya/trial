
-- SQL DATABASE FOR A CAR RENTAL MANAGEMENT SYSTEM

DROP DATABASE IF EXISTS car_rental;
CREATE DATABASE car_rental;
USE car_rental;

-- Table: car

DROP TABLE IF EXISTS car;
CREATE TABLE car (
    car_id INT NOT NULL AUTO_INCREMENT,
    car_name VARCHAR(50) NOT NULL,
    car_type VARCHAR(50) NOT NULL,
    car_color VARCHAR(50) NOT NULL,
    car_price INT NOT NULL,
    car_status VARCHAR(50) NOT NULL,
    PRIMARY KEY (car_id)
);

-- Table: customer

DROP TABLE IF EXISTS customer;
CREATE TABLE customer (
    customer_id INT NOT NULL AUTO_INCREMENT,
    customer_name VARCHAR(50) NOT NULL,
    customer_address VARCHAR(50) NOT NULL,
    customer_phone VARCHAR(50) NOT NULL,
    customer_email VARCHAR(50) NOT NULL,
    PRIMARY KEY (customer_id)
);

-- Table: rental

DROP TABLE IF EXISTS rental;
CREATE TABLE rental (
    rental_id INT NOT NULL AUTO_INCREMENT,
    car_id INT NOT NULL,
    customer_id INT NOT NULL,
    rental_date DATE NOT NULL,
    return_date DATE NOT NULL,
    PRIMARY KEY (rental_id),
    FOREIGN KEY (car_id) REFERENCES car(car_id),
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
);

-- Table: user

DROP TABLE IF EXISTS user;
CREATE TABLE user (
    user_id INT NOT NULL AUTO_INCREMENT,
    user_name VARCHAR(50) NOT NULL,
    user_password VARCHAR(50) NOT NULL,
    PRIMARY KEY (user_id)
);

-- INSERTING DATA INTO THE TABLES

INSERT INTO car (car_name, car_type, car_color, car_price, car_status) VALUES
('Toyota', 'Sedan', 'White', 10000, 'Available'),
('Honda', 'Sedan', 'Black', 8000, 'Available'),
('Nissan', 'Sedan', 'Red', 9000, 'Available'),
('Toyota', 'SUV', 'White', 12000, 'Available'),
('Honda', 'SUV', 'Black', 10000, 'Available'),
('Nissan', 'SUV', 'Red', 11000, 'Available'),
('Toyota', 'Hatchback', 'White', 8000, 'Available'),
('Honda', 'Hatchback', 'Black', 6000, 'Available'),
('Nissan', 'Hatchback', 'Red', 7000, 'Available');

INSERT INTO customer (customer_name, customer_address, customer_phone, customer_email) VALUES
('John', '123 Main Street', '123-456-7890','westoh@gmail.com'),
('Mary', '456 Main Street', '123-456-7891','veteran@gmail.com'),
('Peter', '789 Main Street', '123-456-7892','peterscarlet@gmail.com'),
('Susan', '101 Main Street', '123-456-7893','susie1@gmail.com');

INSERT INTO rental (car_id, customer_id, rental_date, return_date) VALUES
(1, 1, '2020-01-01', '2020-01-05'),
(2, 2, '2020-01-01', '2020-01-05'),
(3, 3, '2020-01-01', '2020-01-05'),
(4, 4, '2020-01-01', '2020-01-05');
