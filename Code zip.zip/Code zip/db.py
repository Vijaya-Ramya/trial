import sqlite3

class Database:
    def __init__(self, db):
        self.conn = sqlite3.connect(db)
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS car (id INTEGER PRIMARY KEY, car_name text, car_type text, car_color text, car_price text, car_status text)")
        self.conn.commit()

    def fetch(self):
        self.cur.execute("SELECT * FROM car")
        rows = self.cur.fetchall()
        return rows

    def insert(self, car_name, car_type, car_color, car_price, car_status):
        self.cur.execute("INSERT INTO car VALUES (NULL, ?, ?, ?, ?, ?)", (car_name, car_type, car_color, car_price, car_status))
        self.conn.commit()

    def remove(self, id):
        self.cur.execute("DELETE FROM car WHERE id=?", (id,))
        self.conn.commit()

    def update(self, id, car_name, car_type, car_color, car_price, car_status):
        self.cur.execute("UPDATE car SET car_name = ?, car_type = ?, car_color = ?, car_price = ?, car_status = ? WHERE id = ?", (car_name, car_type, car_color, car_price, car_status, id))
        self.conn.commit()

    def __del__(self):
        self.conn.close()

# db = Database('store.db')

# db.insert("Ford", "SUV", "Red", "10000", "Available")
# db.insert("Honda", "Sedan", "Blue", "20000", "Available")
# db.insert("Toyota", "SUV", "Green", "30000", "Available")
# db.insert("BMW", "Sedan", "Black", "40000", "Available")
# db.insert("Audi", "SUV", "White", "50000", "Available")

